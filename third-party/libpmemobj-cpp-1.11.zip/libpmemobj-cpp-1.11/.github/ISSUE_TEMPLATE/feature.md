---
name: Feature
about: Feature your request
labels: "Type: Feature"
---
# FEAT: <!-- fill the title of feature -->

## Rationale

<!-- fill this out -->

## Description

<!-- fill this out -->

## API Changes

<!-- fill this out -->

## Implementation details

<!-- fill this out if possible -->

## Meta

<!-- fill this out -->
