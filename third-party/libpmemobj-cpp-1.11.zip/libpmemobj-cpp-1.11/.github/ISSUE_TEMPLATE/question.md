---
name: Question
about: Do you have question regarding libpmemobj-cpp? Don't hesitate to ask.
labels: "Type: Question"
---
# QUESTION: <!-- fill the title of question -->

## Details

<!-- fill this out -->

<!--
For questions and other non-bugs, you could use http://groups.google.com/group/pmem
You could also chat with members of the PMDK/libpmemobj-cpp team real-time on the #pmem IRC channel on OFTC
-->
