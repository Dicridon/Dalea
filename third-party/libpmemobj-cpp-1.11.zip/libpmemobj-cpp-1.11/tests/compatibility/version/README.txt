Those tests are implemented mainly to check whether compatibility test
framework is working correctly.
