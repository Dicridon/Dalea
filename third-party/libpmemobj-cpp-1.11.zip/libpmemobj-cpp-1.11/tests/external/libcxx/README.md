This directory contains tests copied from https://github.com/llvm-mirror/libcxx
and modified to test pmem::obj containers.

For information on how these tests are licensed, see LICENSE.txt file in this
directory.
